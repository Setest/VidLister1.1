<?php
require_once (dirname(dirname(__FILE__)) . '/vlvideo.class.php');
class vlVideo_mysql extends vlVideo {}