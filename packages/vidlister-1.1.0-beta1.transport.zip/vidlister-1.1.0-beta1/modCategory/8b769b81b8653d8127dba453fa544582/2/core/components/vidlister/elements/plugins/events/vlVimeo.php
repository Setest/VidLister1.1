<?php
$events = array();
$events['OnVidListerImport'] = array('priority' => 0,'propertyset' => 0);
return $events;